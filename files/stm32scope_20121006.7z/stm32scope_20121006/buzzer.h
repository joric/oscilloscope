/** \file
*/

#ifndef BUZZER_H
#define BUZZER_H

void beep(void);	///< "normal" beep
void lbeep(void);	///< longer beep

#endif

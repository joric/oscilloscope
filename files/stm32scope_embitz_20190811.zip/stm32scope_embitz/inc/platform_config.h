#ifndef __PLATFORM_CONFIG_H
#define __PLATFORM_CONFIG_H

#include "stm32f10x.h"

#define BUZZER_PORT                     GPIOB
#define BUZZER_PIN                  	GPIO_Pin_0
#define RCC_APB2Periph_GPIO_BUZZER      RCC_APB2Periph_GPIOB

#define LED_PORT                        GPIOC
#define LED_PIN                         GPIO_Pin_13
#define RCC_APB2Periph_GPIO_LED         RCC_APB2Periph_GPIOC

#endif /* __PLATFORM_CONFIG_H */


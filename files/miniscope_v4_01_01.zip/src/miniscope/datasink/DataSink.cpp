/** \file
*/

#include "datasink/DataSink.h"

void DataSink::Trigger(void)
{

}

void DataSink::Process(const Data &data, int channel)
{

}





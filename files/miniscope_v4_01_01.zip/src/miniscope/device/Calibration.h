#ifndef CalibrationH
#define CalibrationH

struct DEV_CALIBRATION
{
	int offset;
	float gain;
};

#endif

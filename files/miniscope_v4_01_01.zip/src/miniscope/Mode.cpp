#include "Mode.h"

enum E_MODE mode;

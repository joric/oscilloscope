//---------------------------------------------------------------------------

#ifndef CommonUnitH
#define CommonUnitH
//---------------------------------------------------------------------------

#include <Forms.hpp>
#include "gnugettext.hpp"

class TfrmCommon: public TForm
{
public:
	__fastcall TfrmCommon(Classes::TComponent* AOwner);
};

#endif
